package com.example.springboot;

//import ch.qos.logback.core.model.Model;
import com.fasterxml.jackson.databind.util.JSONPObject;
import netscape.javascript.JSObject;
import org.springframework.context.annotation.Bean;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.provisioning.InMemoryUserDetailsManager;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

@RestController
public class HelloController {

//	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//		http
//				.authorizeHttpRequests((requests) -> requests
//						.requestMatchers("/", "/home").permitAll()
//						.anyRequest().authenticated()
//				)
//				.formLogin((form) -> form
//						.loginPage("/login")
//						.permitAll()
//				)
//				.logout((logout) -> logout.permitAll());
//
//		return http.build();
//	}
//
//	@Bean
//	public UserDetailsService userDetailsService() {
//		UserDetails user =
//				User.withDefaultPasswordEncoder()
//						.username("user")
//						.password("password")
//						.roles("USER")
//						.build();
//
//		return new InMemoryUserDetailsManager(user);
//	}

	@GetMapping("/")
	public HashMap<String, String> index() {
		int i = 1;
		HashMap<String, String> hashMap = new HashMap<>();
		hashMap.put("user", "active");
		return  hashMap;
	}

	@GetMapping("/api2")
		public HashMap<String, String> api2() {
			HashMap<String, String> hashMap = new HashMap<>();
			hashMap.put("user", "active");
			hashMap.put("type", "articles");
			hashMap.put("id", "1");
    		hashMap.put("user", "user ram");
			hashMap.put("title", "JSON:API paints my bikeshed!");
			hashMap.put("id", "2");
		    hashMap.put("user", "user shayam");
			hashMap.put("title", "JSON:API paints my bikeshed!");

//			---------------------
			return  hashMap;
		}

	@GetMapping("/about")
	public String about() {
		return "Hello -----------  about Page   -------------- " ;
	}

//	@GetMapping("/greeting")
//	public String greeting(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
//		model.addAttribute("name", name);
//		return "greeting";
//	}
}
